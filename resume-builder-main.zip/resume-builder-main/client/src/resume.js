const resume = {

    title: "",
    template: "",
    personal: {
        firstName: "",
        lastName: "",
        email: "",
        phone: "",
        website: ""
    },
    education: [
        {
            university: "",
            degree: "",
            startDate: "",
            endDate: "",
            gpa: ""
        }
    ],
    experience: [
        {
            title: "",
            organisation: "",
            startDate: "",
            endDate: "",
            description: ['']
        }

    ],
    skills: [
        {
            skillName: '',
            keywords: ['']
        }
    ],
    projects: [
        {
            projectName: '',
            keywords: [''],
            projectDescription: [''],
            projectLink: ''
        }
    ],
    achivements: [
        {
            title: '',
            date: '',
            organisation: '',
            description: ['']
        }
    ],
}
export default resume;
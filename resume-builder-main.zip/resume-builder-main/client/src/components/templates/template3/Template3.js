import React from 'react';


const Template3 = (props) => {
    return(
        <div className="container">

            <div></div>

            


        </div>
    )
}

export default Template3;
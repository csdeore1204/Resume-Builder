const templates = ['template1', 'template2'];

export default templates;

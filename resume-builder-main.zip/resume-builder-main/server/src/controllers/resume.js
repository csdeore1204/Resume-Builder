import Resume from '../models/resume.js';
import crudControllers from '../utils/crud.js';

export default crudControllers(Resume);


